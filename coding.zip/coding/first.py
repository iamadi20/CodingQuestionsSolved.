subsstatus=input("Enter the state: ") 
def count(subsstatus):
	subscriberCount=0
	if subsstatus=='ACTIVE'or'NEVER ACTIVE':
		subscriberCount+=1
		print(subscriberCount)
		break
	return subscriberCount

count(subsstatus)