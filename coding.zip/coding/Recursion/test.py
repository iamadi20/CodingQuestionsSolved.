import requests

url = "https://dk3t0dxhd8.execute-api.ap-south-1.amazonaws.com/vitaran/upload-image2"

payload={}
files=[
  ('file',('Rectangle485.png',open('C:/Users/USER/Downloads/Rectangle485.png','rb'),'image/png'))
]
headers = {}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)
