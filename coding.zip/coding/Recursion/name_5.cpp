// Print name 5 times
#include <iostream>
using namespace std;
// int cnt=0;
// void printName()
// {
// 	if (cnt>=5) return;

// 	cout<<"aditya"<<endl;
	
// 	cnt++;
// 	printName();
	
// }
// int main()
// {
// 	printName();
// 	return 0;
// }

void printName(int i,int n)
{
	if (i>n) return;

	cout<<"aditya"<<endl;

	printName(i+1,n);
}


int main()
{
	int n;
	cin>>n;
	printName(1,n);
	return 0;
}