import webbrowser
# Enter the url
url="https://www.youtube.com/watch?v=t1XCzWlYWeA"
download=url[:12]+"ss"+url[12:]
webbrowser.open(url)