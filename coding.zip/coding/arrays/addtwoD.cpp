#include<iostream>
using namespace std;


int main()
{
	int i,j,k,l;
	cout<<"Enter the elements of 2 D :";
	cin>>k>>l;
	int arr[k][l];

	cout<<"Insert the 2D elements: ";
	for(i=0;i<k;i++)
	{
		for(j=0;j<l;j++)
		{
			cin>>arr[i][j];
		}
	}


	int matrix_sum=0;
	cout<<"Elements after addition are: "<<endl;
	for(i=0;i<k;i++)
	{
		for(j=0;j<l;j++)
		{
			matrix_sum+=arr[i][j];
		}
	}

	cout<<"Sum is:"<<matrix_sum;


	return 0;
}