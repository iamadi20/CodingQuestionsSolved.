// sum of the elements
#include <iostream>
using namespace std;

int main()
{
	int size,i;
	cout<<"Enter the size: ";
	cin>>size;
	int arr[size];

	cout<<"Elements add: "<<endl;
	for(i=0;i<size;i++)
		cin>>arr[i];

	int sum=0;
	for(i=0;i<size;i++)
		sum+=arr[i];

	cout<<"Sum of elements would be: "<<sum;

	return 0;
}