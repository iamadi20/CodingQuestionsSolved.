#include<iostream>
using namespace std;

int main()
{
	int i,size;

	cout<<"Enter the size: ";
	cin>>size;
	int arr[size];

	cout<<"Enter the elements: ";
	for(i=0;i<size;i++)
		cin>>arr[i];

	int max=arr[0];
	int max_val=0;
	for(i=0;i<size;i++)
	{
		if (arr[i]>max)
		{
			max=arr[i];
		}
	}
	cout<<"The maximum element is: "<<max;
	return 0;
}