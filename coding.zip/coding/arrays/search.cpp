// Search an element in an array
#include<iostream>
using namespace std;

int main()
{
	int i,size,key;
	cout<<"enter the size: ";
	cin>>size;
	int arr[size];
	cout<<"Enter elements: "<<endl;
	for(i=0;i<size;i++)
		cin>>arr[i];

	cout<<"Enter the key which you wish to search: ";
	cin>>key;
	for(i=0;i<size;i++)
		if (key==arr[i])
			cout<<"The search element is at index: "<<i<<endl;
		return -1;

return 0;
}