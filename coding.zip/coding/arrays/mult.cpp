#include <iostream>
using namespace std;

int main()
{
	int size,i;
	cout<<"Enter the size: ";
	cin>>size;
	int arr[size];
	cout<<"Elements: "<<endl;
	for(i=0;i<size;i++)
		cin>>arr[i];
	int mult=1;
	for(i=0;i<size;i++)
		mult*=arr[i];
	cout<<"Elements after substraction is: "<<mult;
	return 0;
}