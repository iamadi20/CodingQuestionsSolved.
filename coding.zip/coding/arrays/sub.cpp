// Subtract from an array
#include<iostream>
using namespace std;

int main()
{
	int size,i;
	cout<<"Enter the size: ";
	cin>>size;
	int arr[size];
	cout<<"Elements: "<<endl;
	for(i=0;i<size;i++)
		cin>>arr[i];
	int sub=0;
	for(i=0;i<size;i++)
		sub-=arr[i];
	cout<<"Elements after substraction is: "<<sub;
	return 0;
}