#include <iostream>
using namespace std;

int main()
{

	int i,size;

	cin>>size;
	int arr[size];

	for(i=0;i<size;i++)
		cin>>arr[i];

	for(i=0;i<size;i++){
			cout<<arr[i]<<endl;}	

	int temp=0;
	int index;

	cin>>index;
	if(index>=0 && index<size)
	{
		temp=arr[index];
		for(i=index;i<size-1;i++)
		{
			arr[i]=arr[i+1];
		}
		size--;
	}else{
		cout<<"Invalid Index.";
	}


	for(i=0;i<size;i++)
		cout<<arr[i]<<endl;

return 0;  

}