#include<iostream>
using namespace std;

int main()
{
	int size;
	int tgt,i,j;
	cout<<"Enter size: ";
	cin>>size;
	int arr[size];
	cout<<"Enter elements:"<<endl;
	for(i=0;i<size;i++)
		cin>>arr[i];

	cout<<"Enter the target sum: ";
	cin>>tgt;

	for(i=0;i<size;i++)
	{
		for(j=i+1;j<size;j++)
		{
			if (arr[i]+arr[j]==tgt)
			{
				cout<<"Pair Found: "<<i<<" "<<j<<endl;
			}
		}
	}
	// cout<<i<<j;
	return 0;
}