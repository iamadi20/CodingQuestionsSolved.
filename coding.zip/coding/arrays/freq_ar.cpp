#include<iostream>
using namespace std;

int main()
{
	// int main()
	int size,i,j;
	int count=0;
	cout<<"Enter the size: ";
	cin>>size;

	int arr[size];

	cout<<"Enter the elements:";
	for(i=0;i<size;i++)
	{
		cin>>arr[i];
	} 

	cout<<"Occurence of all are: "<<endl;
	for(i=0;i<size;i++)
	{
		bool found=true;
		if(arr[i]==found)
			continue;
		count=1;
		for(j=i+1;j<size;j++)
		{
			if (arr[i]==arr[j])
			{
				arr[j]=found;
				count++;
			}
		}

		cout<<arr[i]<<" "<<count<<endl;

	}
	return 0;
}