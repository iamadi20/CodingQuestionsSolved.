#include<iostream>
using namespace std;

int main()
{
	int size,i;
	bool search;

	cout<<"Enter Size: ";
	cin>>size;

	int arr[size];

	cout<<"Enter the elements in the array: "<<endl;
	for(i=0;i<size;i++)
		cin>>arr[i];

	int key;

	cout<<"Enter the key that you wish to search: ";
	cin>>key;
	int temp=0;
	for(i=0;i<size;i++)
	{
		if (key==arr[i])
		{
			temp=arr[0];
			arr[0]=arr[i];
			arr[i]=temp;
			// arr[i]=arr[0];
			cout<<"key Found at index "<<i<<" and the value is: "<<key<<endl;
			// search=true;
		}
	}

	for(i=0;i<size;i++)
		cout<<arr[i]<<endl;


	return 0;

}