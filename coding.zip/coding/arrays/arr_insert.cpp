#include <iostream>
using namespace std;

int main()
{
	int size,n,i;

	cout<<"Enter the size:";
	cin>>size;
	int arr[size];

	for(i=0;i<size;i++)
		cin>>arr[i];

	cout<<"Arrays before insertion: "<<endl;
	for(i=0;i<size;i++)
		cout<<arr[i]<<endl;
	cout<<"Enter the element you wish to append:";
	cin>>n;

	arr[size]=n;
	size++;

	cout<<"Arrays after insertion: "<<endl;
	for(i=0;i<size;i++)
		cout<<arr[i]<<endl;

	cout<<"The size is: "<<size;
	return 0;

}