#include <iostream>
using namespace std;



void Display(int arr[])
{
	int i,size;
	cout<<"Arrays after insertion: "<<endl;
	for(i=0;i<size;i++)
		cout<<arr[i]<<endl;

}


int main()
{
	int size,n,i,k;

	cout<<"Enter the size:";
	cin>>size;
	int arr[size];

	for(i=0;i<size;i++)
		cin>>arr[i];

	Display(arr[]);
	cout<<"Enter at what index you wish to add :";
	cin>>n;

	cout<<"Enter the element you wish to append:";
	cin>>k;
	if (n>size)
	{
		cout<<"Not Correct, Plz Try again"<<endl;
		// Display(arr)
	}
	else
	{
		for(i=size;i>n;i--)
		{
			arr[i]=arr[i-1];
		}
		arr[n]=k;
		size++;
	}
	// Display(arr);

	return 0;


}

