def max_array():
	arr=[]
	num=int (input("Enter the size: "))

	for i in range(1,num+1):
		ele=int(input("Enter the elements: "))
		arr.append(ele)

	max_val=arr[0]

	for i in arr:
		if i>max_val:
			max_val=i
	return max_val


print(max_array())