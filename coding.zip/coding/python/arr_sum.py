# def sum_arr():
# 	arr=[]

# 	size=int(input("Enter the size: "))

# 	for i in range(1,size+1):
# 		ele=int(input("Enter the elements :\n"))
# 		arr.append(ele)

# 	sum_ele=0

# 	for i in arr:
# 		sum_ele=sum_ele+arr[i]

# 	return sum_ele


# print("The Sum of the elements are: ",sum_arr())

def lsearch():
	arr=[]
	size=int(input("Enter the size: "))

	for i in range(1,size+1):
		ele=int(input("Enter elements: "))
		arr.append(ele)

	key=int(input("Enter the key: "))

	for i in arr:
		print(arr[i])
		# if arr[i] == key:
		# 	print("Found at",i)
		# else:
		# 	print("Not Found")

	return key


lsearch()