lists={}
test=open('test.txt',mode='r',encoding='utf-8').read().split('\n')

for i in test:
    if len(lists)==0:
        lists[i.split(',')[0]]=[i.split(',')[1]]

print(test)    