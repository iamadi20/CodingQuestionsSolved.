n=int(input("Enter"))

i=1
# j=1
while i<=n:
	j=1
	while(j<=n):
		print("*")
		j=j+1
	# print("\n")
	i=i+1
	print("\n")
