#include<iostream>
using namespace std;

int main()
// {
// 	int a;
// 	int *c,*d;

// 	a=30;

// 	c=&a;
// 	d=c;
// 	a=a+10;
// 	cout<<*c;

// }

// int main()

{

       int c[3][4]={1, 2, 3, 4, 4, 3, 2, 1, 7, 8, 9, 0}; 

       cout<<c+1<<endl<<&c+1;

       return 0;

}