#include <iostream>
using namespace std;

int main()
{
	int i,n;
	i=1;
	int sum=0;
	cout<<"N: ";
	cin>>n;

	while(i<=n)
	{
		sum=sum+i;
		i++;
	}
	cout<<sum<<" ";
	return 0;
}