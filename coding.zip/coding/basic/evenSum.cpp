#include<iostream>
using namespace std;

// int main()
// {
// 	int n,sum=0;
// 	cout<<"Enter the num: ";
// 	cin>>n;

// 	int i=2;
// 	while(i<=n)
// 	{
// 		sum+=i;
// 		i++;
// 	}
// 	cout<<"Sum is: "<<sum;
// 	return 0;
// }

int main()
{
	int n,sum=0;
	int i=1;

	cout<<"Enter the num: ";
	cin>>n;

	for(i=1;i<=n;i++)
	{
		if ((i%2)==0)
		{
			sum+=i;
		}
	}
	cout<<"Sum is: "<<sum;
	return 0;
}