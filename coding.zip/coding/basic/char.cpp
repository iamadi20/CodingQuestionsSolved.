#include <iostream>
using namespace std;
// ucase-65-90, lcase-97-122,digit-48-57
int main()
{
	char ch;

	cout<<"Enter a character:";
	cin>>ch;

	if(ch>=65 && ch<=90)
		cout<<"uppercase";
	else if(ch>=97 && ch<=122)
		cout<<"lowercase";
	else
		cout<<"Digit";
	

	return 0;
}