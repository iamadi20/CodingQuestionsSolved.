def printNums(n):
    num=1
    for i in range(1,num+1):
        return i


print(printNums(5))
