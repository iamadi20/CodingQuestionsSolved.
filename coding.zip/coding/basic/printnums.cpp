#include <iostream.h>
#include <conio.h>
int main()
{
    int n,num=1;
    cout<<"Enter a number";
    cin>>n;
    for(i=1;i<=n+1;i++)
    {
        if (num<=n)
            cout<<n;
    }

    return 0;
}