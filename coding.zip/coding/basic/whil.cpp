#include <iostream>
using namespace std;

int main()
{
	int n;
	cout<<"N:";
	cin>>n;
	int i=1;
	while(i<=n)
	{
		cout<<i<<endl;
		i++;
	}
return 0;
}