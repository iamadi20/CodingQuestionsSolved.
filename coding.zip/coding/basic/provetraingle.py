def proveATriangle(a,b,c):
    if a+b>c:
        return 'yes'
    elif b+c>a:
        return 'yes'
    elif c+a>b:
        return 'yes'
    else:
        return 'nope'

print(proveATriangle(0,0,0))