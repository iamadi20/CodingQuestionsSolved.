test_str=input("Enter the string: ")
res=''.join(format(ord(i),'08b')for i in test_str)
res2=int(res,2)
print("The string after conversion is ",str(res2))